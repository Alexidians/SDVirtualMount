import os
import subprocess
import pyvhd
import pycdlib
import sys
import time
import threading
import json
from io import BytesIO
import uuid
import string
import win32api
import win32file
import win32con
import win32security
import ctypes

VIRTUAL_STORAGE_TYPE_DEVICE = 0x00000001  # VHDX
ATTACH_VIRTUAL_DISK_FLAG_READ_ONLY = 0x00000001

# Define the path to the VirtualDisk.dll
VIRTUAL_DISK_DLL_PATH = r"C:\Windows\System32\VirtualDisk.dll"

# Load the Virtual Disk library using the full path
virtual_disk_lib = ctypes.WinDLL(VIRTUAL_DISK_DLL_PATH)

# Define necessary constants and structures
class VIRTUAL_STORAGE_TYPE(ctypes.Structure):
    _fields_ = [
        ("DeviceId", ctypes.c_uint32),
        ("VendorId", ctypes.c_char * 256)
    ]

class VHD_OPEN_FLAG(ctypes.Structure):
    _fields_ = [
        ("Version", ctypes.c_uint32)
    ]

class VHD_ATTACH_INFO(ctypes.Structure):
    _fields_ = [
        ("Version", ctypes.c_uint32),
        ("StorageType", VIRTUAL_STORAGE_TYPE)
    ]

# Function to get an available drive letter
def get_available_drive_letter():
    for letter in range(ord('E'), ord('Z') + 1):
        drive = f"{chr(letter)}:\\"
        if not os.path.exists(drive):
            return drive
    return None

def mount_vhdx(vhdx_path, read_only=True, removable=True):
    # Check if the VHDX file exists
    if not os.path.exists(vhdx_path):
        raise FileNotFoundError(f"The specified VHDX file does not exist: {vhdx_path}")

    print(f"Attempting to open VHDX at: {vhdx_path}")

    # Prepare the storage type for VHDX
    storage_type = VIRTUAL_STORAGE_TYPE(0, b'Microsoft')

    # Prepare the open flags
    open_flags = VHD_OPEN_FLAG()
    open_flags.Version = 1

    # Encode the path correctly for Windows API
    vhdx_path_wchar = vhdx_path.encode('utf-16le')

    vhd_handle = ctypes.c_void_p()
    result = virtual_disk_lib.OpenVirtualDisk(
        ctypes.byref(storage_type),
        vhdx_path_wchar,  # Use the encoded path
        0,  # No special open flags
        ctypes.byref(open_flags),
        ctypes.byref(vhd_handle)
    )

    if result != 0:
        error_message = f"Failed to open VHDX: {result} (Error Code: {ctypes.GetLastError()})"
        print(error_message)
        raise Exception(error_message)

    try:
        # Prepare attachment info structure
        attach_info = VHD_ATTACH_INFO()
        attach_info.Version = 1
        attach_info.StorageType = storage_type

        # Set attachment flags
        attach_flags = 0
        if read_only:
            attach_flags |= 1  # Set the read-only flag

        # Call the AttachVirtualDisk function
        result = virtual_disk_lib.AttachVirtualDisk(
            vhd_handle,
            ctypes.byref(attach_info),
            attach_flags,
            0,
            None,
            None
        )

        if result != 0:
            error_message = f"Failed to attach VHDX: {result} (Error Code: {ctypes.GetLastError()})"
            print(error_message)
            raise Exception(error_message)

        # Find an available drive letter
        drive_letter = get_available_drive_letter()
        if drive_letter is None:
            raise Exception("No available drive letters.")

        print(f"Successfully attached {vhdx_path} as a virtual disk.")
        print(f"Assigned drive letter: {drive_letter}")

        return drive_letter  # Return the assigned drive letter for unmounting later

    finally:
        # Clean up
        if vhd_handle:
            virtual_disk_lib.CloseHandle(vhd_handle)


def unmount_vhdx(vhdx_path):
    """Unmount a VHDX file."""
    # Get the handle of the VHDX file
    vhd_handle = win32file.CreateFile(
        vhdx_path,
        win32file.GENERIC_READ | win32file.GENERIC_WRITE,
        win32file.FILE_SHARE_READ | win32file.FILE_SHARE_WRITE,
        None,
        win32file.OPEN_EXISTING,
        win32file.FILE_ATTRIBUTE_NORMAL,
        None
    )

    if vhd_handle == win32file.INVALID_HANDLE_VALUE:
        raise Exception("Failed to open VHDX file for unmounting.")

    try:
        # Call the DetachVirtualDisk function to unmount the VHDX
        result = virtual_disk_lib.DetachVirtualDisk(
            vhd_handle,
            0  # Detach flags (0 for default)
        )

        if result != 0:  # Check for errors
            raise Exception(f"Failed to detach VHDX: {result}")

        print(f"Successfully unmounted {vhdx_path}.")

    finally:
        # Clean up
        win32file.CloseHandle(vhd_handle)

def is_drive_letter_available(drive_letter):
    """Check if the specified drive letter is available."""
    return not os.path.exists(f"{drive_letter}\\")

def get_available_drive_letter():
    """Automatically detect an available drive letter."""
    used_letters = {drive[0] for drive in os.popen('wmic logicaldisk get name').read().splitlines() if drive}
    for letter in string.ascii_uppercase:
        if letter not in used_letters:
            return letter
    raise RuntimeError("No available drive letters.")

def mount_vhdx_function(vhdx_path):
    """Mount a VHDX file using VhdxTool."""
    if not os.path.isfile(vhdx_path):
        raise FileNotFoundError(f"The specified VHDX file does not exist: {vhdx_path}")

    # Run the VhdxTool command to mount the VHDX
    command = f'"vhdxtool.exe" mount "{vhdx_path}"'
    try:
        subprocess.run(command, shell=True, check=True)
        print(f"Mounted VHDX: {vhdx_path}")
    except subprocess.CalledProcessError as e:
        print(f"Error mounting VHDX: {e}")

def unmount_vhdx_old(vhdx_path):
    """Unmount a VHDX file using VhdxTool."""
    if not os.path.isfile(vhdx_path):
        raise FileNotFoundError(f"The specified VHDX file does not exist: {vhdx_path}")

    # Run the VhdxTool command to unmount the VHDX
    command = f'"vhdxtool.exe" unmount "{vhdx_path}"'
    try:
        subprocess.run(command, shell=True, check=True)
        print(f"Unmounted VHDX: {vhdx_path}")
    except subprocess.CalledProcessError as e:
        print(f"Error unmounting VHDX: {e}")


def mount_vhdx_old(vhd_path, readonly):
    """Mount a VHD file."""
    vhd_path_original = vhd_path
    if not os.path.isfile(vhd_path):
        raise FileNotFoundError(f"The specified VHD file does not exist: {vhd_path}")
    
    if readonly:
        isoid = str(uuid.uuid4())
        iso_path = os.path.join("tmp/SDVirtualMount/vhdx/readonly", isoid + ".iso")
        os.makedirs("tmp/SDVirtualMount/vhdx/readonly", exist_ok=True)
        convert_vhdx_to_iso(vhd_path, iso_path)
        vhd_path = iso_path

        command = f"Mount-DiskImage -ImagePath '{vhd_path}'"
        subprocess.run(["powershell", "-Command", command], check=True)
        print(f"Mounted VHDX: {vhd_path_original}")
    else:
        mount_vhdx_function(vhd_path)

def convert_vhdx_to_iso(vhdx_path, iso_path):
    """Convert a VHDX file to an ISO file using QEMU."""
    if not os.path.isfile(vhdx_path):
        raise FileNotFoundError(f"The specified VHDX file does not exist: {vhdx_path}")

    # Using QEMU to convert VHDX to ISO
    command = f'qemu-img convert -f vhdx -O raw "{vhdx_path}" "{iso_path}"'
    subprocess.run(command, shell=True, check=True)
    print(f"Converted VHDX to ISO: {iso_path}")

def convert_directory_to_iso(directory_path, iso_path, volume_label="Unnamed"):
    """
    Convert a directory to an ISO file using pycdlib.

    :param directory_path: Path to the directory to be converted.
    :param iso_path: Path where the output ISO file will be saved.
    """
    if not os.path.exists(directory_path):
        raise FileNotFoundError(f"Directory not found: {directory_path}")

    # Create a new ISO object
    iso = pycdlib.PyCdlib()
    iso.new(vol_ident=volume_label)

    # Helper function to add files and directories recursively
    def add_directory_to_iso(path, iso_path_in_iso):
        for item in os.listdir(path):
            full_path = os.path.join(path, item)
            iso_path_item = os.path.join(iso_path_in_iso, item)

            if os.path.isdir(full_path):
                # Add directory
                iso.add_directory(iso_path_item)
                # Recursively add the contents of the directory
                add_directory_to_iso(full_path, iso_path_item)
            else:
                # Add file
                iso.add_file(full_path, iso_path_item)

    # Add the directory to the ISO
    add_directory_to_iso(directory_path, "/")

    # Write the ISO to a file
    iso.write(iso_path)
    iso.close()
    print(f"ISO creation successful: {iso_path}")


def convert_iso_to_vhdx(iso_path, vhdx_path):
    """Convert an ISO file to a VHDX file using QEMU."""
    if not os.path.isfile(iso_path):
        raise FileNotFoundError(f"The specified ISO file does not exist: {iso_path}")

    # Using QEMU to convert ISO to VHDX
    command = f'qemu-img convert -f raw -O vhdx "{iso_path}" "{vhdx_path}"'
    subprocess.run(command, shell=True, check=True)
    print(f"Converted ISO to VHDX: {vhdx_path}")


def resize_vhdx(vhdx_path, new_size):
    """Resize a VHDX file using QEMU."""
    if not os.path.isfile(vhdx_path):
        raise FileNotFoundError(f"The specified VHDX file does not exist: {vhdx_path}")

    # Using QEMU to resize the VHDX file
    command = f'qemu-img resize "{vhdx_path}" {new_size}'
    subprocess.run(command, shell=True, check=True)
    print(f"Resized VHDX to: {new_size}")

def convert_directory_to_vhdx(directory_path, vhd_path, max_size):
    iso_id = str(uuid.uuid4())
    os.makedirs("tmp/SDVirtualMount/vhd-converter/temp_iso/", exist_ok=True)
    tmp_iso_conv_path = os.path.join("tmp/SDVirtualMount/vhd-converter/temp_iso/", iso_id + ".iso")
    tmp_iso_label = "VHD_CONVERTER_TMP_" + iso_id
    if len(tmp_iso_label) > 32:
        tmp_iso_label = "VHD_CONV_TMP_" + iso_id
        if len(tmp_iso_label) > 32:
            tmp_iso_label = "CONV_TMP_" + iso_id
            if len(tmp_iso_label) > 32:
                tmp_iso_label = "TMP_" + iso_id
                if len(tmp_iso_label) > 32:
                    tmp_iso_label = iso_id
                    if len(tmp_iso_label) > 32:
                        tmp_iso_label = "TMP"
    try:
     convert_directory_to_iso(os.path.abspath(directory_path), os.path.abspath(tmp_iso_conv_path), tmp_iso_label)
    except Exception as e:
     convert_directory_to_iso(os.path.abspath(directory_path), os.path.abspath(tmp_iso_conv_path), "TMP")
    convert_iso_to_vhdx(os.path.abspath(tmp_iso_conv_path), os.path.abspath(vhd_path))
    resize_vhdx(os.path.abspath(vhd_path), max_size)

def convert_directory_to_vhd_broken(directory_path, vhd_path, max_size=None):
    """Convert a directory to a VHD file with an optional maximum size."""
    if not os.path.isdir(directory_path):
        raise NotADirectoryError(f"The specified directory does not exist: {directory_path}")

    # Calculate the total size of files in the directory
    total_size = 0
    for root, _, files in os.walk(directory_path):
        for file in files:
            total_size += os.path.getsize(os.path.join(root, file))

    # Check if the total size exceeds max_size
    if max_size is not None and total_size > max_size:
        raise ValueError(f"The total size of files ({total_size} bytes) exceeds the maximum size limit ({max_size} bytes).")

    # Create a new VHD file
    # Use the appropriate method to create a VHD
    vhd = pyvhd.VHD(vhd_path, total_size)  # Assuming this is the correct constructor

    # Open the VHD file to write
    with vhd.open() as vhd_file:
        for root, _, files in os.walk(directory_path):
            for file in files:
                file_path = os.path.join(root, file)
                # Add the file to the VHD, maintaining the directory structure
                vhd_file.add_file(file_path, os.path.relpath(file_path, directory_path))

    print(f"Converted directory to VHD: {vhd_path}")

def set_vhdx_volume_label(vhdx_path, new_label):
    """Rename the volume label of a mounted VHDX file."""
    # Mount the VHDX file
    mount_vhdx(vhdx_path)

    # PowerShell command to get the drive letter of the mounted VHDX
    command = f"""
    $vhdx = Get-DiskImage -ImagePath '{vhdx_path}'
    $volume = Get-Volume -DiskNumber $vhdx.DiskNumber
    $volume.DriveLetter
    """
    
    # Get the drive letter
    result = subprocess.run(["powershell", "-Command", command], capture_output=True, text=True)
    
    if result.returncode != 0:
        print(f"Failed to get drive letter for VHDX: {result.stderr.strip()}")
        unmount_vhdx(vhdx_path)
        return

    drive_letter = result.stdout.strip()

    # PowerShell command to rename the volume label
    command = f"Set-Volume -DriveLetter {drive_letter} -NewFileSystemLabel '{new_label}'"
    
    try:
        subprocess.run(["powershell", "-Command", command], check=True)
        print(f"Renamed VHDX volume label to: {new_label}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to rename VHDX volume label: {e}")
    finally:
        # Unmount the VHDX file after renaming
        unmount_vhdx(vhdx_path)

def reformat_drive(drive_path):
    """Reformat an existing drive to the same size."""
    # Get the current size of the drive
    size_command = f"qemu-img info --output=json {drive_path}"
    try:
        result = subprocess.run(size_command, shell=True, check=True, capture_output=True, text=True)
        size_info = json.loads(result.stdout)
        size = size_info['virtual-size']
    except Exception as e:
        print(f"Error getting drive size: {e}")
        return
    
    # Reformatting the drive
    format_command = f"qemu-img create -f vhdx -o size={size} {drive_path}"
    try:
        subprocess.run(format_command, shell=True, check=True)
        print(f"Drive reformatted successfully: {drive_path}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to reformat drive: {e}")

def main():
    # Check for ISO path argument
    if len(sys.argv) < 2:
        print("Invalid Command line parameters.")
        sys.exit(1)

    # Get ISO path and check for read-only flag
    vhd_path = sys.argv[1]
    readonly = "--read-only" in sys.argv
    mount = "--mount" in sys.argv
    dir_to_vhd = "--dir-to-vhdx" in sys.argv
    set_volume_label = "--set-volume-label" in sys.argv
    unmount = "--unmount" in sys.argv
    resize = "--resize" in sys.argv
    
    if resize:
        resize_vhdx(os.path.abspath(vhd_path), sys.argv[2])
    if set_volume_label:
        set_vhdx_volume_label(os.path.abspath(vhd_path), sys.argv[2])
    if dir_to_vhd:
        convert_directory_to_vhdx(sys.argv[2], os.path.abspath(vhd_path), sys.argv[3])
    if unmount:
        unmount_vhdx(os.path.abspath(vhd_path))
    if mount:
        mount_vhdx(os.path.abspath(vhd_path), readonly)

if __name__ == "__main__":
    main()


# try running with: test.iso blank PoopOS_0.0.0.0 --convert. just make usre to have a directory called blank
# jk. its vhd: test.vhd blank 100000 POOPOS_0.0.0.0 --dir-to-vhd