import os
import subprocess
import pyvhd
import pycdlib
import sys
import time
import threading
import json
from io import BytesIO
import uuid


def mount_vhd(vhd_path, readonly):
    """Mount a VHD file."""
    vhd_path_original = vhd_path
    if not os.path.isfile(vhd_path):
        raise FileNotFoundError(f"The specified VHD file does not exist: {vhd_path}")
    
    if readonly:
        isoid = str(uuid.uuid4())
        iso_path = os.path.join("tmp/SDVirtualMount/vhd/readonly", isoid + ".iso")
        os.makedirs("tmp/SDVirtualMount/vhd/readonly", exist_ok=True)
        convert_vhd_to_iso(vhd_path, iso_path)
        vhd_path = iso_path

    # PowerShell command to mount the VHD
    command = f"Mount-DiskImage -ImagePath '{vhd_path}'"
    subprocess.run(["powershell", "-Command", command], check=True)
    print(f"Mounted VHD: {vhd_path_original}")

def convert_vhd_to_iso(vhd_path, iso_path):
    """Convert a VHD file to an ISO file."""
    if not os.path.isfile(vhd_path):
        raise FileNotFoundError(f"The specified VHD file does not exist: {vhd_path}")

    # Using PowerShell command to convert VHD to ISO
    command = f"Convert-VHD -Path '{vhd_path}' -DestinationPath '{iso_path}' -Format Dynamic"
    subprocess.run(["powershell", "-Command", command], check=True)
    print(f"Converted VHD to ISO: {iso_path}")

def convert_directory_to_iso(directory_path, iso_path, volume_label="Unnamed"):
    """
    Convert a directory to an ISO file using pycdlib.

    :param directory_path: Path to the directory to be converted.
    :param iso_path: Path where the output ISO file will be saved.
    """
    if not os.path.exists(directory_path):
        raise FileNotFoundError(f"Directory not found: {directory_path}")

    # Create a new ISO object
    iso = pycdlib.PyCdlib()
    iso.new(vol_ident=volume_label)

    # Helper function to add files and directories recursively
    def add_directory_to_iso(path, iso_path_in_iso):
        for item in os.listdir(path):
            full_path = os.path.join(path, item)
            iso_path_item = os.path.join(iso_path_in_iso, item)

            if os.path.isdir(full_path):
                # Add directory
                iso.add_directory(iso_path_item)
                # Recursively add the contents of the directory
                add_directory_to_iso(full_path, iso_path_item)
            else:
                # Add file
                iso.add_file(full_path, iso_path_item)

    # Add the directory to the ISO
    add_directory_to_iso(directory_path, "/")

    # Write the ISO to a file
    iso.write(iso_path)
    iso.close()
    print(f"ISO creation successful: {iso_path}")

def convert_iso_to_vhd(iso_path, vhd_path):
    """
    Convert an ISO file to a VHD file using PowerShell with diskpart.

    :param iso_path: Path to the input ISO file.
    :param vhd_path: Path where the output VHD file will be saved.
    """
    if not os.path.exists(iso_path):
        raise FileNotFoundError(f"ISO file not found: {iso_path}")

    # Create VHD using diskpart
    diskpart_script = f"""
    SELECT VIRTUAL DISK FILE="{vhd_path}"
    CREATE VIRTUAL DISK
    ATTACH VIRTUAL DISK
    """
    
    try:
        # Execute the diskpart command to create VHD
        subprocess.run(["powershell", "-Command", diskpart_script], check=True)

        # Copy the ISO contents to the VHD (You can modify this to suit your needs)
        subprocess.run(["powershell", "-Command", f"Mount-DiskImage -ImagePath '{iso_path}'"], check=True)
        subprocess.run(["powershell", "-Command", f"Copy-Item -Path 'E:\\*' -Destination '{vhd_path}\\' -Recurse"], check=True)  # Ensure 'E:' is the correct drive letter for the mounted ISO

        print(f"Conversion successful: {vhd_path}")
    except subprocess.CalledProcessError as e:
        print(f"Error during conversion: {e}")


def resize_vhd(vhd_path, new_size):
    """
    Resize an existing VHD file using PowerShell.

    :param vhd_path: Path to the existing VHD file.
    :param new_size_gb: New maximum size of the VHD file in gigabytes.
    """
    try:
        # Construct the PowerShell command to resize the VHD
        command = f"Resize-VHD -Path '{vhd_path}' -SizeBytes {new_size}"

        # Execute the PowerShell command
        subprocess.run(["powershell", "-Command", command], check=True)

        print(f"VHD file resized successfully to: {new_size} Bytes.")
    except subprocess.CalledProcessError as e:
        print(f"Error resizing VHD: {e}")

def convert_directory_to_vhd(directory_path, vhd_path, max_size):
    iso_id = str(uuid.uuid4())
    os.makedirs("tmp/SDVirtualMount/vhd-converter/temp_iso/", exist_ok=True)
    tmp_iso_conv_path = os.path.join("tmp/SDVirtualMount/vhd-converter/temp_iso/", iso_id + ".iso")
    tmp_iso_label = "VHD_CONVERTER_TMP_" + iso_id
    if len(tmp_iso_label) > 32:
        tmp_iso_label = "VHD_CONV_TMP_" + iso_id
        if len(tmp_iso_label) > 32:
            tmp_iso_label = "CONV_TMP_" + iso_id
            if len(tmp_iso_label) > 32:
                tmp_iso_label = "TMP_" + iso_id
                if len(tmp_iso_label) > 32:
                    tmp_iso_label = iso_id
                    if len(tmp_iso_label) > 32:
                        tmp_iso_label = "TMP"
    try:
     convert_directory_to_iso(os.path.abspath(directory_path), os.path.abspath(tmp_iso_conv_path), tmp_iso_label)
    except Exception as e:
     convert_directory_to_iso(os.path.abspath(directory_path), os.path.abspath(tmp_iso_conv_path), "TMP")
    convert_iso_to_vhd(os.path.abspath(tmp_iso_conv_path), os.path.abspath(vhd_path))
    resize_vhd(os.path.abspath(vhd_path), max_size)

def convert_directory_to_vhd_broken(directory_path, vhd_path, max_size=None):
    """Convert a directory to a VHD file with an optional maximum size."""
    if not os.path.isdir(directory_path):
        raise NotADirectoryError(f"The specified directory does not exist: {directory_path}")

    # Calculate the total size of files in the directory
    total_size = 0
    for root, _, files in os.walk(directory_path):
        for file in files:
            total_size += os.path.getsize(os.path.join(root, file))

    # Check if the total size exceeds max_size
    if max_size is not None and total_size > max_size:
        raise ValueError(f"The total size of files ({total_size} bytes) exceeds the maximum size limit ({max_size} bytes).")

    # Create a new VHD file
    # Use the appropriate method to create a VHD
    vhd = pyvhd.VHD(vhd_path, total_size)  # Assuming this is the correct constructor

    # Open the VHD file to write
    with vhd.open() as vhd_file:
        for root, _, files in os.walk(directory_path):
            for file in files:
                file_path = os.path.join(root, file)
                # Add the file to the VHD, maintaining the directory structure
                vhd_file.add_file(file_path, os.path.relpath(file_path, directory_path))

    print(f"Converted directory to VHD: {vhd_path}")


def unmount_vhd(vhd_path):
    """Unmount a VHD file."""
    command = f"Unmount-DiskImage -ImagePath '{vhd_path}'"
    subprocess.run(["powershell", "-Command", command], check=True)
    print(f"Unmounted VHD: {vhd_path}")

def set_vhd_volume_label(vhd_path, volume_label):
    """Set the volume label of a mounted VHD."""
    # Mount the VHD
    mount_vhd(vhd_path, False)

    # Use PowerShell to set the volume label
    command = f"Get-Volume | Where-Object {{ $_.FileSystemLabel -eq '' }} | Set-Volume -NewFileSystemLabel '{volume_label}'"
    subprocess.run(["powershell", "-Command", command], check=True)

    # Unmount the VHD
    unmount_vhd(vhd_path)

    print(f"Set volume label '{volume_label}' for VHD: {vhd_path}")

def main():
    # Check for ISO path argument
    if len(sys.argv) < 2:
        print("Usage: SDVirtualMount.py path/to/virtual/disc.vhd [--read-only]")
        print("Additional Usage: SDVirtualMount.py path/to/output/virtual/disc.vhd path/to/input/directory 1073741824 ExampleOS_8.04 --convert")
        sys.exit(1)

    # Get ISO path and check for read-only flag
    vhd_path = sys.argv[1]
    readonly = "--read-only" in sys.argv
    mount = "--mount" in sys.argv
    dir_to_vhd = "--dir-to-vhd" in sys.argv
    set_volume_label = "--set-volume-label" in sys.argv
    unmount = "--unmount" in sys.argv
    resize = "--resize" in sys.argv
    
    if resize:
        resize_vhd(vhd_path, int(sys.argv[2]))
    if set_volume_label:
        set_vhd_volume_label(vhd_path, sys.argv[2])
    if dir_to_vhd:
        convert_directory_to_vhd(sys.argv[2], vhd_path, int(sys.argv[3]))
        if sys.argv[4]:
            set_vhd_volume_label(vhd_path, sys.argv[4])
    if unmount:
        unmount_vhd(vhd_path)
    if mount:
        mount_vhd(vhd_path, readonly)

if __name__ == "__main__":
    main()


# try running with: test.iso blank PoopOS_0.0.0.0 --convert. just make usre to have a directory called blank
# jk. its vhd: test.vhd blank 100000 POOPOS_0.0.0.0 --dir-to-vhd